﻿Public Class Form1

    'Private Sub NoActiveRadio_CheckedChanged(sender As Object, e As EventArgs) Handles TurnOnRadio.CheckedChanged, TurnOffRadio.CheckedChanged, NoActiveRadio.CheckedChanged
    '    If TurnOnRadio.Checked = True And Then
    '        ListBox1.Items.Add("Включен")

    '        Flag.Checked = False
    '    End If
    '    If TurnOffRadio.Checked = True And TurnOff = 0 Then
    '        ListBox1.Items.Add("Выключен")

    '        Flag.Checked = False
    '    End If
    '    If NoActiveRadio.Checked = True And NoActive = 0 Then
    '        ListBox1.Items.Add("Не активен")

    '        Flag.Checked = False
    '    End If
    'End Sub

    Private Sub Flag_Click(sender As Object, e As EventArgs) Handles Flag.Click
        'ListBox1.Items.Add("Включен")
        ListBox1.Items.RemoveAt(ListBox1.Items.Count - 1)
    End Sub

    Private Sub TurnOnRadio_Click(sender As Object, e As EventArgs) Handles TurnOnRadio.Click
        Flag.Checked = True
        Flag.Enabled = True
        ListBox1.Items.Add("Включен")

    End Sub

    Private Sub TurnOffRadio_Click(sender As Object, e As EventArgs) Handles TurnOffRadio.Click
        Flag.Checked = False
        Flag.Enabled = True
        ListBox1.Items.Add("Выключен")
    End Sub

    Private Sub NoActiveRadio_Click(sender As Object, e As EventArgs) Handles NoActiveRadio.Click
        Flag.Enabled = False
        ListBox1.Items.Add("Не активен")
    End Sub
End Class
